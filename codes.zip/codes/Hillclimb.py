import random

# Distance matrix (example graph)
distances = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]

# Calculate total distance of a tour
def calculate_distance(tour):
    total = 0
    for i in range(len(tour) - 1):
        total += distances[tour[i]][tour[i+1]]
    total += distances[tour[-1]][tour[0]]  # return to start
    return total

# Generate neighbor by swapping two cities
def get_neighbor(tour):
    new_tour = tour[:]
    i, j = random.sample(range(len(tour)), 2)
    new_tour[i], new_tour[j] = new_tour[j], new_tour[i]
    return new_tour

# Hill Climbing Algorithm
def hill_climbing():
    # Initial random solution
    current_solution = list(range(len(distances)))
    random.shuffle(current_solution)
    current_cost = calculate_distance(current_solution)

    while True:
        neighbor = get_neighbor(current_solution)
        neighbor_cost = calculate_distance(neighbor)

        # Move to better neighbor
        if neighbor_cost < current_cost:
            current_solution = neighbor
            current_cost = neighbor_cost
        else:
            break

    return current_solution, current_cost

# Run algorithm
solution, cost = hill_climbing()

print("Best Tour:", solution)
print("Minimum Cost:", cost)