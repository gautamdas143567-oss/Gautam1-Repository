import math

board = [' ' for _ in range(9)]

def print_board():
    for i in range(0, 9, 3):
        print(board[i], "|", board[i+1], "|", board[i+2])
    print()

def check_winner(brd, player):
    win_positions = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ]
    for pos in win_positions:
        if brd[pos[0]] == brd[pos[1]] == brd[pos[2]] == player:
            return True
    return False

def is_full(brd):
    return ' ' not in brd

def minimax(brd, depth, is_max):
    if check_winner(brd, 'O'):
        return 1
    elif check_winner(brd, 'X'):
        return -1
    elif is_full(brd):
        return 0

    if is_max:
        best = -math.inf
        for i in range(9):
            if brd[i] == ' ':
                brd[i] = 'O'
                score = minimax(brd, depth+1, False)
                brd[i] = ' '
                best = max(score, best)
        return best
    else:
        best = math.inf
        for i in range(9):
            if brd[i] == ' ':
                brd[i] = 'X'
                score = minimax(brd, depth+1, True)
                brd[i] = ' '
                best = min(score, best)
        return best

def ai_move():
    best_score = -math.inf
    move = -1
    for i in range(9):
        if board[i] == ' ':
            board[i] = 'O'
            score = minimax(board, 0, False)
            board[i] = ' '
            if score > best_score:
                best_score = score
                move = i
    board[move] = 'O'

def player_move():
    move = int(input("Enter position (0-8): "))
    if board[move] == ' ':
        board[move] = 'X'
    else:
        print("Invalid move!")
        player_move()

def main():
    print("Welcome to Tic Tac Toe")
    print_board()

    while True:
        player_move()
        print_board()

        if check_winner(board, 'X'):
            print("You win!")
            break
        if is_full(board):
            print("Draw!")
            break

        print("AI turn...")
        ai_move()
        print_board()

        if check_winner(board, 'O'):
            print("AI wins!")
            break
        if is_full(board):
            print("Draw!")
            break

main()