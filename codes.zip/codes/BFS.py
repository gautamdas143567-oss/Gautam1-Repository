from collections import deque

# Graph (Adjacency List)
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': ['F'],
    'F': []
}

def bfs_unique_paths(graph, start, goal):
    queue = deque([[start]])  # store paths
    result = []

    while queue:
        path = queue.popleft()
        node = path[-1]

        # If goal reached → store path
        if node == goal:
            result.append(path)
            continue

        # Explore neighbors
        for neighbor in graph[node]:
            if neighbor not in path:   # avoid cycles → unique path
                new_path = list(path)
                new_path.append(neighbor)
                queue.append(new_path)

    return result


# Driver code
start = 'A'
goal = 'F'

paths = bfs_unique_paths(graph, start, goal)

print("Unique paths from", start, "to", goal, ":")
for p in paths:
    print(p)